from django.apps import AppConfig


class FaceDetectConfig(AppConfig):
    name = 'face_detect'
